﻿// #  Test step     Test Data            Expected Result    Actual Result    Status
//    ----------------------------------------------------------------------
// 1  Navigate to   |URL: nashformat.ua | NashFormat main | NashFormat main | PASS
//    NashFormat.ua |                   | page opens      | page opens      |
//    page          |                   |                 |                 |
//    -----------------------------------------------------------------------
// 2  Find the link |URL: nashformat.ua/authors | Page "Всі автори"| Page "Всі автори"| PASS
//    "Всі автори"  |                           | has opened       | has opened       |
//    and open it   |                           |                  |                  |
//    ------------------------------------------------------------------------
// 3  Search some   | Search query: "Григорій"  | Matching results | Matching results | PASS
//    data by Search|                           | are shown on the | are shown on the |
//    box           |                           | page             | page             |
//    ------------------------------------------------------------------------
// 4  Open product  |                   | Product page has | Product page has| PASS
//    page          |                   | been opened      | been opened     |  
//    ------------------------------------------------------------------------
// 5  Click on the   |                  | The product has  | The product has | PASS
//    button "Купити"|                  | been added to    | been added to   |
//                   |                  | "Корзина"        | "Корзина"       |
//    ------------------------------------------------------------------------
// 6  Press the button     |     | The page nashformat.ua/cart | The page nashformat.ua/cart| PASS
//    "Оформити замовлення"|        | has been opened             | has been opened
//    ----------------------------------------------------------------------------------
// 7  Check if the button  |            | Button is displayed         | Button is displayed| PASS
//    "Далі" is displayed  |            |                             |                    | 

using System;
using Xunit;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;
using OpenQA.Selenium.Support.UI;

namespace Selenium_TestProject_demo1
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            // Create a driver instance for chromedriver
            IWebDriver driver = new ChromeDriver();

            //Navigate to NashFormat.ua page
            driver.Navigate().GoToUrl("https://nashformat.ua/");

            //Maximize the window
            driver.Manage().Window.Maximize();

            //Find the link "Всі автори" by text
            driver.FindElement(By.LinkText("Всі автори")).Click();

            // Find the Search box by selector - Name: "keyword"
            IWebElement element = driver.FindElement(By.Name("keyword"));
            element.SendKeys("Григорій");
            element.Submit();

            // Find product by Xpath and selector - [data-product] with value 23354 
            driver.FindElement(By.XPath("//a[@data-product='23354']")).Click();
            

            //Find the button "Купити" by Xpath with full path to it
            driver.FindElement(By.XPath("/html/body/div[1]/div[2]/div[2]/div/div[3]/div[2]/div[2]/div[2]/div[1]/div/div[1]/form/div/div[2]/button")).Click();

            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            //Thread.Sleep(2500);
            //Find element "Оформити замовлення" by Xpath #cartPopupFooter > div.btns > a:nth-child(2)
            wait.Until(webDriver => webDriver.FindElement(By.XPath("/html/body/div[3]/div/div/div[3]/div[2]/a[2]")).Displayed);
            driver.FindElement(By.XPath("/html/body/div[3]/div/div/div[3]/div[2]/a[2]")).Click();
            
            // Find button "далі" and check if its displayed on the page
            IWebElement actual = driver.FindElement(By.LinkText("Далі"));
            Assert.True(actual.Displayed);

            //Close the browser
            //driver.Quit();
            driver.Close();
            
        }
    }
}
