﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Vpfayfer_demo2
{
    class Animal
    {
        private int BirthYear;
        private string Color;
        public string name;
        
        public string species = "None";

        static DateTime now = DateTime.Today;
        int CurrentYear = int.Parse(now.ToString("yyyy"));
        public int birth
        {
            get { return BirthYear; }
            set { BirthYear = birth; }
        }
        public string color
        {
            get { return Color; }
            set { Color = color; }
        }


        public Animal(string Name, int birth, string color)
        {
            BirthYear = birth;
            Color = color;
            name = Name;
            
        }
        virtual public void Move()
        {
            Console.WriteLine("I am moving !!!");
        }
        virtual public void Input()
        {
            Console.WriteLine("Input name");
            name =  Console.ReadLine();
            Console.WriteLine("Input color");
            color = Console.ReadLine();
            Console.WriteLine("Input birth year");
            birth = int.Parse(Console.ReadLine());
        }
        virtual public void Output()
        {
            Console.WriteLine($"Animal name: {name} color is: {color}, animal birthyear is: {birth}, species: {species}");
        }
        public double GetAge()
        {
            //Console.WriteLine($"The {name} age is: " + (CurrentYear - BirthYear ));
            return (CurrentYear - BirthYear);
            
        }
        public virtual string Voice()
        {
            return "Pfffffff";
        }
        public override string ToString()
        {
            return Voice();
        }
        public virtual string Species()
        {
            return species;
        }
        public Tuple<string, int, string, string> Cout()
        {
            return new Tuple<string, int, string, string>(name, birth, color, species);
        }


    }
    class Fish : Animal
    {
        private string kind;
        public string ikind
        {
            set
            {
                kind = ikind;
            }
            get
            {
                return kind;
            }
        }
        
        public Fish(string Name1, int Birth, string Color, string fspecies  ) : base(Name1, Birth, Color)
        {
            this.name = Name1;
            this.birth = Birth;
            this.color = Color;
            this.species = fspecies;

        }
        public override void Move()
        {
            Console.WriteLine("get away! fish on the wave");
        }
        public override void Output()
        {
            
            Console.WriteLine($"Fish name {name}, kind is: {kind}, his species is: {species}, animal birthyear is: {birth}" );

        }
        public override void Input()
        {
            //base.Input();
            Console.WriteLine("Input kind of the fish");
            this.kind = Console.ReadLine();
            //Console.WriteLine("Input species of the fish");
            //species = Console.ReadLine();

        }
       public string Kind()
        {
            return kind;
        }
        public override string Voice()
        {
            Console.WriteLine($"The {name} voice is: bul- bul- bul");
            return kind;
        }

    }
    

        class Program
    {
        static void Main(string[] args)
        {

            List<Animal> animals = new List<Animal>();
            animals.Add(new Animal("Tigero", 2018, "red-blue"));
            animals.Add(new Fish("Nemo", 2020, "red-blue", "Sea"));
            animals.Add(new Animal("Lione", 2021, "red-blue"));
            animals.Add(new Fish("Gilly", 1998, "green-yellow", "River"));
            animals.Add(new Fish("Lolly", 2000, "red-blue", "River"));
            Console.WriteLine("------------------------------------");
            Console.WriteLine("Input fish Kind:");
            foreach (var any in animals)
            {
                if (any.species != "None")
                {
                    try
                    {
                        Console.WriteLine($"THE Kind of {any.name} is: ");
                        any.Input();
                        if ((any.Voice() == ""))
                        {
                            throw new Exception("This fish is not belong for any kind ?!");
                        }  
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine($"Write one more time the kind of {any.name}");
                        any.Input();
                    }
                }
            }

                Console.WriteLine("------------------------------------");
                Console.WriteLine("Before sorting:");
                foreach (var any in animals)
                {
                    any.Output();
                }
                Console.WriteLine("------------------------------------");

                animals.Sort((x, y) => x.Species().CompareTo(y.Species()));
                Console.WriteLine("After sorting:");
                foreach (var any in animals)
                {
                    any.Output();
                }
                Console.WriteLine("------------------------------------");
                Console.WriteLine("Output info about fishes elder then 3 years");
                foreach (var any in animals)
                {
                    if (any.species != "None" && any.GetAge() > 3.0)
                    {
                            any.Output();
                            any.Voice();
                    }
                }
                TextWriter tw = new StreamWriter("SavedAnimals.txt");

                foreach (var any in animals)
                {
                    tw.WriteLine(any.Cout());
                }
                tw.Close();

            

        }
    }
}

