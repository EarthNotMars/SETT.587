﻿using System;

namespace hw_6
{
    class Program
    {
        public static int Div(int x, int y)
        {
            int z = x / y;
            return  z;
        }
        static void Main(string[] args)
        {
            bool nextDivide = true;
            while (nextDivide)
            {
                Console.WriteLine("Here you can divide x on y. Input x and y");
                
                try
                {
                    int x = int.Parse(Console.ReadLine());
                    int y = int.Parse(Console.ReadLine());
                    Console.WriteLine(Div(x, y));
                    if (x.Equals(typeof(double)) && y.Equals(typeof(double)))
                    {
                        throw new Exception("Can't divide 2 values with double type");
                    }
                }

                catch (DivideByZeroException ex)
                {
                    Console.WriteLine("Can't divide on zero" + ex.Message);
                }
                catch (FormatException ex)
                {
                    Console.WriteLine("Input value is not valid" + ex.Data);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Can't divide 2 values with double type" + e.Message);
                }
                finally
                {
                    Console.WriteLine("Would you like to continue ? Type: Y/y");
                    string g = Console.ReadLine();
                    if (g=="Y" || g=="y")
                    {
                        nextDivide = true;
                    }
                    else
                    {
                        nextDivide = false;
                    }

                }
            }
        }
    }
}
