﻿using System;
using System.Collections.Generic;
using System. IO;
using System.Text.RegularExpressions;
namespace Hw_7
{
    class Program
    {
        static void Main(string[] args)
        {
            string readPath = @"C:\Users\vpfaitc\source\repos\Hw_7\obj\phones.txt";
            string writePath = @"C:\Users\vpfaitc\source\repos\Hw_7\obj\result.txt";
            string writePath1 = @"C:\Users\vpfaitc\source\repos\Hw_7\obj\NewResult.txt";
            Dictionary<string, string> PhoneBook = new Dictionary<string, string>();
            StreamReader reader = new StreamReader(readPath);
            string line;
            string[] parts = { };
            int i = 0;
            string userName;

            while ((line = reader.ReadLine()) != null)
            {
                parts = line.Split(',');
                PhoneBook.Add(parts[i], parts[i + 1]);
            }
            reader.Close();
            // Output dictionary and values 
            foreach (KeyValuePair<string, string> keyValue in PhoneBook)
            {
                Console.WriteLine(keyValue.Key + " - " + keyValue.Value);
            }
            // Write only number to file Phones.txt
            using (StreamWriter sw = new StreamWriter(writePath, false, System.Text.Encoding.Default))
            {
                foreach (KeyValuePair<string, string> keyValue in PhoneBook)
                {
                    sw.WriteLine(keyValue.Value);
                }
            }
            //print phone number after user - enter Name
            Console.WriteLine("Which phone number to print, choose user from list: Jeremy, Alex, Groovy, Nickolas, Vladion, Riman, Polre, Zxerk, POlit "); 
            try
            {
                userName = Console.ReadLine();
                if (userName == "")
                {
                    throw new Exception("field is empty");
                } else
                {
                    Console.WriteLine($"Phone nuber of {userName} is : {PhoneBook[userName]}");
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Empty field or user is not exist, please write the User name from list");
                userName = Console.ReadLine();
            }
            //Change all phone numbers, which are in format 80######### into new format
            //+380#########. 
            Regex regex = new Regex("[8][0]");
            string k = "";
            Dictionary<string, string> NewPhoneBook = new Dictionary<string, string>();

            foreach (KeyValuePair<string, string> keyValue in PhoneBook)
            {
                
                MatchCollection matches = regex.Matches(keyValue.Value);
                if (matches.Count > 0)
                {
                    NewPhoneBook.Add(keyValue.Key, ($"+3{keyValue.Value}"));
                }
                //result write into file "New.txt«
                using (StreamWriter sw = new StreamWriter(writePath1, false, System.Text.Encoding.Default))
                {
                    foreach (KeyValuePair<string, string> keyValue1 in NewPhoneBook)
                    {
                        sw.WriteLine(keyValue1.Value);
                    }
                }





            }
            //Output dicitonare with new code 
            foreach (KeyValuePair<string, string> keyValue in NewPhoneBook)
            {
                Console.WriteLine(keyValue.Key + " - " + keyValue.Value);
            }

        }



    }
}

