﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace HW_8
{
   
    public abstract class Shape
    {
       private string name;
        string Name
        {
            get
            {
               return  name;
            }
            set
            {
                name = value ;
            }
        }
        void shape(string Name)
        {
            name = Name;
        }
        public abstract void Area(); //created for making list
        public abstract void Perimetr();
        public abstract void Output();
        public abstract double prmtr(); // created for return method
        public abstract string NameOut();
        public abstract double AreaS();
    }
    class Circle: Shape
    {
        public string name;
        public double radius;
        double pi = 3.14;
        
        
        public void circle(string Name, double Radius)
        {
            radius = Radius;
            name = Name;
        }
        public override void Area()
        {
            Console.WriteLine("Area is: " + pi *Math.Pow(radius,2));
        }
        public override double AreaS() //created for sorting because of "cant convert void to double"
        {
            return pi * Math.Pow(radius, 2);
        }
        public override void Perimetr()
        {
            Console.WriteLine("Perimetr is: " + 2*pi*radius);
            
        }
         public override double prmtr()
        {
            return 2 * pi * radius;
        }
        public override void Output()
        {
            Console.WriteLine("Circle name is: "+name);
        }
        public override string NameOut()
        {
            return name;
        }




    }
    class Square : Shape
    {
       public  string name;
        public double side;
        public void square(string Name, double Side)
        {
            side = Side;
            name = Name;
        }
        public override void Area()
        {
            Console.WriteLine("Area is: " + Math.Pow(side, 2));
        }
        public override double AreaS()
        {
            return Math.Pow(side, 2);
        }
        public override void Perimetr()
        {
            Console.WriteLine("Perimetr is: " + 4 * side);
        }
        public override double prmtr()
        {
            return 4 * side;
        }
        public override void Output()
        {
            Console.WriteLine("Square name is: " + name);
        }
        public override string NameOut()
        {
            return name;
        }
    }
   
    class Program
    {
        static void Main(string[] args)
        {
            int c = 0;
            List <Shape> shapes = new List<Shape>();

            
                for (int i = 1; i<=5; i++)
                {
                    Console.WriteLine($"Please input name of the {i} circle and his radius");
                    string Name = Console.ReadLine();
                    double Radius = double.Parse(Console.ReadLine());
                    shapes.Add(new Circle { name = Name, radius = Radius }) ;
                }
                for (int i = 5; i <= 10; i++)
                {
                    Console.WriteLine($"Please input name of the {i} square and his side");
                    string Name = Console.ReadLine();
                    double Radius = double.Parse(Console.ReadLine());
                    shapes.Add(new Square { name = Name, side = Radius });
                }
            Console.WriteLine("List of all shapes: ");
            foreach (Shape shape in shapes)
            {
                shape.Output();
                shape.Perimetr();
                shape.Area();
                
            }
            shapes.Sort((a, b) => b.prmtr().CompareTo(a.prmtr()));
            Console.WriteLine("------------------------------------");
            Console.WriteLine($"Shape with the biggest perimetr: name - {shapes[0].NameOut()}, with perimetr - {shapes[0].prmtr()}");
            Console.WriteLine("------------------------------------");
            Console.WriteLine("Sorted list by Area: ");
            shapes.Sort((a, b) => b.AreaS().CompareTo(a.AreaS()));
            
            foreach (Shape shape in shapes)
            {
                shape.Output();
                shape.Perimetr();
                shape.Area();
            }

        }
    }
}
