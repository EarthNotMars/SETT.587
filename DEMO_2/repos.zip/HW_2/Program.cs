﻿using System;

namespace HW_2
{
    class Program
    {
        static void Main(string[] args)
        {
            //A
            float a;
            float b;
            float c;
            Console.WriteLine("write 3 numbers and the App will check if they are situated in range [-5;5] ");
            a = float.Parse(Console.ReadLine());
            b = float.Parse(Console.ReadLine());
            c = float.Parse(Console.ReadLine());
            if (a>-5 && a < 5)
            {
                Console.WriteLine("The first number is situated in range [-5;5]");
            }
            else
            {
                Console.WriteLine("The first number is not situated in range [-5;5]");
            }
            if (b > -5 && b < 5)
            {
                Console.WriteLine("The second number is situated in range [-5;5]");
            }
            else
            {
                Console.WriteLine("The second number is not situated in range [-5;5]");
            }
            if (c > -5 && c < 5)
            {
                Console.WriteLine("The third number is situated in range [-5;5]");
            }
            else
            {
                Console.WriteLine("The third number is not situated in range [-5;5]");
            }
            //B
            if (a > b && a > c)
            {
                Console.WriteLine("First value " + a + " is the biggest");
            }
            else if (b > a && b > c)
            {
                Console.WriteLine("Second value " + b + " is the biggest");
            }
            else if (c > b && c > a)
            {
                Console.WriteLine("Third value " + c + " is the biggest");
            }
            else {
                Console.WriteLine("Numbers are equal");
            }
        }
    }
}
