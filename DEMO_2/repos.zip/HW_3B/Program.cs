﻿using System;

namespace HW_3B
{
    class Program
    {
        static void Main(string[] args)
        {
            int year;
            int month;
            Console.WriteLine("Please, write the year");
            year = int.Parse(Console.ReadLine());
            Console.WriteLine("Please, write the month (e.g 1,2,3)");
            month = int.Parse(Console.ReadLine());
            switch (month) {
                case 1:
                    Console.WriteLine("Quantity of days in January is 31");
                    break;
                case 2:
                    if (DateTime.IsLeapYear(year))
                    {
                        Console.WriteLine("Quantity of days in February is 29");
                    }
                    else {
                        Console.WriteLine("Quantity of days in January is 28");
                    }
                    break;
                case 3:
                    Console.WriteLine("Quantity of days in March is 31");
                    break;
                case 4:
                    Console.WriteLine("Quantity of days in is 30");
                    break;
                case 5:
                    Console.WriteLine("Quantity of days in  is 31");
                    break;
                case 6:
                    Console.WriteLine("Quantity of days in is 30");
                    break;
                case 7:
                    Console.WriteLine("Quantity of days in  is 31");
                    break;
                case 8:
                    Console.WriteLine("Quantity of days in is 31");
                    break;
                case 9:
                    Console.WriteLine("Quantity of days in is 30");
                    break;
                case 10:
                    Console.WriteLine("Quantity of days in is 31");
                    break;
                case 11:
                    Console.WriteLine("Quantity of days in  is 30");
                    break;
                case 12:
                    Console.WriteLine("Quantity of days in December is 31");
                    break;
               
            }
        }
    }
}
