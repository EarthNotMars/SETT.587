﻿using System;

namespace HW_2C
{
    class Program
    {
        enum HttpErrors
        {
            BadRequest, //400
            Unauthorized, //401
            PaymentRequired //402
        }
        static void Main(string[] args)
        {
            //c
            int val;
            Console.WriteLine("Info about HTTPErrors 400,401,402. Input number");
            val = int.Parse(Console.ReadLine());
            HttpErrors error400 = HttpErrors.BadRequest;
            HttpErrors error401 = HttpErrors.Unauthorized;
            HttpErrors error402 = HttpErrors.PaymentRequired;

            if (val == 400) {
                Console.WriteLine($"Trouble is in: {error400}");
                    }
            else if (val == 401) {
                Console.WriteLine($"Trouble is in: {error401}");
            }
            else if (val == 402)
            {
                Console.WriteLine($"Trouble is in: {error402}");
            }
            else
            {
                Console.WriteLine("No such Errors");
            }
        }
    }
}
