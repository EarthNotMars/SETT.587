﻿using System;

namespace HW_3
    //A
{
    class Program
    {
        static void Main(string[] args)
        {
            string a;
            int aQuantity = 0;
            int oQuantity = 0;
            int iQuantity = 0;
            int eQuantity = 0;

            Console.WriteLine("Write String:");
            a = Console.ReadLine();
            a = a.ToLower();
            foreach (char i in a) {
                switch (i.ToString())
                {
                    case "a":
                        aQuantity++;
                        continue;
                    case "o":
                        oQuantity++;
                        continue;
                    case "i":
                        iQuantity++;
                        continue;
                    case "e":
                        eQuantity++;
                        continue;
                    default:
                        continue;
                                      }
                            }
            Console.WriteLine($"Number of a characters in string {aQuantity}, o - {oQuantity}, i - {iQuantity}, e - {eQuantity}");

        }
    }
}
