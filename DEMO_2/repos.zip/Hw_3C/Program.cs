﻿using System;

namespace Hw_3C
{
    class Person {
        private string name;
        private DateTime Birthyear;
        public static DateTime localDate = DateTime.Now;
        public string pname {
            get {
                return name;
            }
        }
        public DateTime pBirthyear
        {
            get
            {
                return Birthyear;
            }
        }
        public Person()
        {
            this.name = "Elza";
            this.Birthyear = new DateTime(2000, 10, 24);
        }
        public Person(string Name, DateTime date)
        {
            this.name = Name;
            this.Birthyear = date;
        }
        public int Age() {
            TimeSpan ts = localDate - Birthyear;
            // Console.WriteLine("Current age of the person is: " + diff1);
            int k = ts.Days;
            Console.WriteLine(k);
            return k;

        }
        public void Input(string name1, DateTime Birthdate1) {
            this.name = name1;
            this.Birthyear = Birthdate1;
        }
        public void ChangeName(string name1) {
            this.name = name1.ToString();
        } 
        public void Output() {
            Console.WriteLine("Birthyear of the person is: " + pBirthyear.ToString() + " name of the person  " + pname );
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Person Olga = new Person();
            DateTime OlgaB = new DateTime(2020, 12, 12);
            DateTime DanyaB = new DateTime(1995, 11, 12);
            DateTime KatyaB = new DateTime(1994, 10, 12);
            DateTime DenB = new DateTime(1993, 10, 12);
            DateTime EleB = new DateTime(1992, 9, 12);
            DateTime RolandB = new DateTime(2019, 8, 12);
            
            Person[] P = new Person[6];
            P[0] = new Person();
            P[1] = new Person();
            P[2] = new Person();
            P[3] = new Person();
            P[4] = new Person();
            P[5] = new Person();
             
            P[0].Input("OLGA", OlgaB);
            P[1].Input("DANYA", DanyaB);
            P[2].Input("kATYA", KatyaB);
            P[3].Input("dEN", DenB);
            P[4].Input("ELE", EleB);
            P[5].Input("ROLAND", RolandB);
            for (int i = 0; i < 6; i++) {
                P[i].Output();
            }
            for (int i = 0; i < 6; i++)
            {
                int age;
                age = P[i].Age();
                if (age < 5844) {
                    P[i].ChangeName("Very Young");
                        }
                P[i].Output();
                           }



        }
    }
}
