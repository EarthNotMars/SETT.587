﻿using System;

namespace HW_1
{
    class ProgramA
    {
        static void Main(string[] args)
        {
            //Task a)
            int a;
            Console.WriteLine("Please input the lenght of the square");
            a = int.Parse(Console.ReadLine());
            Console.WriteLine("Perimetr of the square is" + " "+4*a);
            Console.WriteLine("Area of the square is" +" "+ a* a);
            Console.ReadLine();
            // Task b)
            int age;
            string name;
            int gender;
            Console.WriteLine("How may I call you ? Select your gender: 1-Male; 2-Female ");
            gender = int.Parse(Console.ReadLine());
            Console.WriteLine("Excuse me, may I have your name ? ");
            name = Console.ReadLine();
            Console.WriteLine("You're looking so young ! What age are you?");
            age = int.Parse(Console.ReadLine());
            if (gender==1) {
                Console.WriteLine("Mister " + " "+name+" "+"the life in"+" " +age+ " "+ "starts to shine with new colours !");
            } else
            {
                Console.WriteLine("Missis " + " " + name + " " + "your" + " " + age + " " +  " "+ "is truly gorgeous ");
            }
            Console.ReadLine();
            //task c
            double r;
            Console.WriteLine("Please input r value:");
            r = double.Parse(Console.ReadLine());
            Console.WriteLine("The lenght of the circle with radius" + " "+ r+" "+"is:" + " " + 2*3.14*r);
            Console.WriteLine("The area of the circle with radius" + " " + r + " " + "is:" + " " +  3.14 * r*r);
            Console.WriteLine("The volume of the circle with radius" + " " + r + " " + "is:" + " " + ((4/3)*r*r*r*3.14));
            Console.ReadLine();
        }
    }
}
