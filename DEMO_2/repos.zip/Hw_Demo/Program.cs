﻿using System;

namespace Hw_Demo
{
    public abstract class Animal
    {
        private int BirthYear;
        private string Color;
        public string name;
        static DateTime now = DateTime.Today;
        public int CurrentYear = int.Parse(now.ToString("yyyy"));
        

        abstract public void Move();
        abstract public void Input();
        abstract public void Output();
        abstract public void GetAge();
        abstract public string Voice();
        public abstract string ToString();
        public abstract string Species();
    }
    class Fish : Animal
    {
        public string Name;
        public Fish(string Name, int birth, string color) { }
        private string kind;
        private string species;
        public string ikind
        {
           set
            {
                kind = ikind;
            }
            get
            {
                return kind;
            }
        }
        public string ispecies
        {
            set
            {
                species = ispecies;
            }
            get
            {
                return species;
            }
        }
        public int birth
        {
            get { return BirthYear; }
            set { BirthYear = birth; }
        }
        public string color
        {
            get { return this.Color; }
            set { Color = color; }
        }
        public override void Move()
        {
            Console.WriteLine("get away! fish on the wave");
        }
        public override void Output()
        {

            Console.WriteLine($"Fish name {name}, kind is: {kind}, his species is: {species}");

        }
        public override void Input()
        {
            base.Input();
            Console.WriteLine("Input kind of the fish");
            ikind = Console.ReadLine();
            Console.WriteLine("Input species of the fish");
            ispecies = Console.ReadLine();

        }
        public override string Species()
        {
            return ispecies;
        }


    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
