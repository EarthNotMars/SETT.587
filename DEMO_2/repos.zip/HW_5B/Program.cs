﻿using System;
using System.Collections.Generic;

namespace HW_5B
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> personal = new Dictionary<int, string>(7);
            for (int i=0; i<=7; i++)
            {
                string name;
                Console.WriteLine("Write name for " + i+ " person");
                name = Console.ReadLine();
                personal.Add(i, name);
            }
            Console.WriteLine("Search person by ID. Please type ID");
            int ID;
            ID = int.Parse(Console.ReadLine());
            switch (ID) {
                case 1:
                    Console.WriteLine($"Person with id: {ID} Has name {personal[1]}");
                    break;
                case 2:
                    Console.WriteLine($"Person with id: {ID} Has name {personal[2]}");
                    break;
                case 3:
                    Console.WriteLine($"Person with id: {ID} Has name {personal[3]}");
                    break;
                case 4:
                    Console.WriteLine($"Person with id: {ID} Has name {personal[4]}");
                    break;
                case 5:
                    Console.WriteLine($"Person with id: {ID} Has name {personal[5]}");
                    break;
                case 6:
                    Console.WriteLine($"Person with id: {ID} Has name {personal[6]}");
                    break;
                case 7:
                    Console.WriteLine($"Person with id: {ID} Has name {personal[7]}");
                    break;
                default:
                    Console.WriteLine("There is no such person with id:" + ID);
                    break;
                            }
           
        }
    }
}
