using System;
using Xunit;
using Vpfayfer_demo2;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;




namespace AnimalsTest
{
    public class Animals_test
    {
        [Fact]
        //Check method GetAge()
        public void Animal_GetAge()
        {
           // Arrange
            int expected = 11;
            //Act
            Animal Neo = new Animal("NEO", 2010, "BLUE");
            double real = Neo.GetAge();
            //Assert
            Assert.Equal(real, expected);

        }

        [Fact]
        //Check property
        public void Fish_Move()
        {
            //Arrange
            Fish sharky = new Fish("sharky", 2015, "blue", "shark");
            sharky.Kind = "Tune";
            //Act
            string expected = sharky.Kind_Out();
            string actual = sharky.Kind;
            //Assert
            Assert.NotEqual("Blue Marlin", expected);
            Assert.Equal(actual, expected);


        }
        // Check if the animals list exist in SavedAnimals.txt 
        [Fact]
        public void OutputWasDone_Test()
        {
            //Arrange
            string path = @"C:\Users\vpfaitc\source\repos\Serialization\bin\Debug\net5.0\SavedAnimals.txt";
            string readText = "None";
            bool exist = false;
            if (File.Exists(path))
            {
                readText = File.ReadAllText(path);   
            }
            //Act
            Regex regex = new Regex("Nemo,");
            MatchCollection matches = regex.Matches(readText);
            if (matches.Count > 0)
            {
                exist = true;
            }
            // Assert
            Assert.True(exist);
        }
    }
}
