﻿using System;
using System.Collections.Generic;

namespace HW_5
{
    public interface IDeveloper

    {
        public string Tool { get; set; }
        void Create();
        void Destroy();
    }
    class Programmer: IDeveloper, IComparable<Programmer>{
        string language;
         public string tool;
        public string Tool {
            get {
                return Tool;
                    }
            set {
                Tool = tool;
            }
        }
        public void Create()
        {
            Console.WriteLine("a");
        }
        public void Destroy() {
            Console.WriteLine("b");
        }
        public int CompareTo(Programmer obj)
        {
            if (this.Tool.Length > obj.Tool.Length)
                return 1;
            if (this.Tool.Length < obj.Tool.Length)
                return -1;
            else
                return 0;
        }
    }
    class Builder: IDeveloper, IComparable<Builder>
    {
        public Builder(string tool)
        {
            Tool = tool;
        }
        string tool;
        public string Tool
        {
            get
            {
                return Tool;
            }
            set
            {
                Tool = tool;
            }
        }
        public void Create()
        {
            Console.WriteLine("c");
        }
        public void Destroy()
        {
            Console.WriteLine("d");
        }
        public int CompareTo(Builder obj)
        {
            if (this.Tool.Length > obj.Tool.Length)
                return 1;
            if (this.Tool.Length < obj.Tool.Length)
                return -1;
            else
                return 0;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            IDeveloper[] obj = { new Programmer(), new Builder("PC"), new Builder("scissor") };
            int i = 0;
            foreach (IDeveloper I in obj) {
                I.Create();
                I.Destroy();      
            }
            obj[0].Tool = "mouse";
            obj[1].Tool = "keyboard";
            obj[2].Tool = "pen";
            obj.Sort();
        }
    }
}
