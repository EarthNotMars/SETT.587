﻿using System;

namespace HW_6B
{
    class Program
    {
        public static void ReadNumber(int min, int max)
        {
            Console.WriteLine($"Please, input 10 numbers from {min} to {max}");
            for (int i = 0; i <= 10; i++)
            {
                int k;
                try
                {
                    k = int.Parse(Console.ReadLine());
                    if (k < min || k > max)
                    {
                        throw new Exception("Value is out of range");
                    }
                    else
                    {
                        Console.WriteLine($"Inputed number {k} is in range from {min} to {max}");
                    }

                }
                catch (FormatException ex)
                {
                    Console.WriteLine("Please type integer value" + ex.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Value is out of range" + e.Data);
                }
            }

        }
        static void Main(string[] args)
        {
            Console.WriteLine("Input range of values : min and max values ");
            int min = int.Parse(Console.ReadLine());
            int max = int.Parse(Console.ReadLine());
            ReadNumber(min, max);
        }
    }
}
