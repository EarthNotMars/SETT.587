﻿using System;

namespace HW_2D
{
    class Program
    {
        struct Dog {
            public string name;
            public int age;
            public string mark;
            public override string ToString()
            {
                              return ($"Name is: {name}, and Mark: {mark} " + age.ToString());
            }
        }
        static void Main(string[] args)
        {
            Dog myDog = new Dog();
            Console.WriteLine("Write Dog name");
            myDog.name = Console.ReadLine();
            Console.WriteLine("Write Dog Mark");
            myDog.mark = Console.ReadLine();
            Console.WriteLine("Write Dog age");
            myDog.age = int.Parse(Console.ReadLine());
            Console.WriteLine(myDog);
            
        }
    }
}
